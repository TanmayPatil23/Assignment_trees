#include "tree.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* FOR BST*/

void initBST(bst *t){
    *t = NULL;
    return;
}

void insertNode(bst *t, long long num, char *name, node *parent){
    if(*t == NULL){
        node *new = (node *)malloc(sizeof(node));
        new->mis = num;
        strcpy(new->name, name);
        new->left = NULL;
        new->right = NULL;
        new->parent = parent;
        *t = new;
    }
    else if((*t)->mis > num) {
        insertNode(&((*t)->left), num, name, *t);
    }
    else if ((*t)->mis < num) {
       insertNode(&((*t)->right), num, name, *t); 
    }
    else {
        return;
    }
    return;
}

void removeNode(bst *t, long long key){ 
    if(*t == NULL)
        return;
    node *p = *t, *q = NULL;
    // Searching for d in the tree
    int side;
    while(p) {
        if(p->mis == key) {
            break;
        }
        q = p;
        if(key < p->mis) {
            p = p->left;
            side = 0;
        }
        if(key > p->mis) {
            p = p->right;
            side = 1;
        }
    }
    if(p == NULL) {
        return;
    }
    if(p->left == NULL && p->right == NULL) {
        if(!q) {
            *t = NULL;
            free(p);
            return;
        }
        if(side) {
            q->right = NULL;
        }
        else {
            q->left = NULL;
        }
        free(p);
        return;
    }
    // For single left child
    if(p->right == NULL && p->left != NULL) {
        if (!q) {
            *t = p->left;
            free(p);
            return;
        }

        if(side == 0) {
            // P is left child of Q
            q->left = p->left;
        }
        else {
            q->right = p->right;   
        }
        free(p);
    }
    // For single right child
    if (p->right != NULL && p->left == NULL) {
        if(!q) {
            *t = p->right;
            free(p);
            return;
        }
        if (side == 0) {
            // P is left child of Q
            q->left = p->right;
        }
        else {
            q->right = p->left;
        }
        free(p);
    }

    if(p->right && p->left) {
        node *r = NULL, *s = NULL;
        s = p->left;
        while (s->right) {
            r = s;
            s = s->right;
        }
        if(!r) {
            p->mis = s->mis;
            p->left = s->left;
            free(s);
        }
        p->mis = s->mis;
        r->right = s->left;
        free(s);
        
    }
    return;
}


boolean search(bst t, long long key){
    if(t == NULL){
        return 0;
    }
    else if(t->mis == key) {
        return 1;
    }
    else if(t->mis > key){
        return search(t->left, key);
    }
    else {
        return search(t->right, key);
    }
}

void postorder(bst t){
    if(!t){
    	printf("TREE EMPTY\n");
        return;
    }
    stack s;
    sinit(&s,10);
    node *current_node = t;
    do{
        while (current_node){ 
            if (current_node->right) 
                push(&s, *(current_node->right)); 
            push(&s, *current_node);
            current_node = current_node->left;
        }

        node *temp = pop(&s);

        if (temp->right && peek(s) == temp->right->mis){ 
            pop(&s); 
            push(&s, *temp); 
            current_node = temp->right;  
        } 
        else { 
            printf("%lld ", temp->mis); 
            current_node = NULL;
        }
    } while (!isempty(s));
    return;
}

void Display_Level(bst t, int level){
    if(!t){
        return;
    }
    else if(level == 1){
        printf("%lld ", t->mis);
    }
    else{
        Display_Level(t->left, level - 1);
        Display_Level(t->right, level - 1);
    }
}

void destroyTree(bst *t){ 
    if(!(*t)){
        return;
    }
    destroyTree(&((*t)->left));
    destroyTree(&((*t)->right));
    free(*t);
    *t = NULL;
}



// FOR STACK

void sinit(stack *s, int len) {
	s->top = 0;
	s->arr = malloc(sizeof(node) * len);
	s->size = len;
	return;
}
void push(stack *s, node n) {
	s->arr[s->top] = n;
	s->top++;
	return;
}
node* pop(stack *s) {
	node *res = (node *)malloc(sizeof(node));
	res = &(s->arr[s->top - 1]);
	s->top--;
	return res;
}
int isempty(stack s) {
	return (s.top == 0);
}
int isfull(stack s) {
	return (s.top == s.size);
}

long long peek(stack s) {
	return (s.arr[s.top - 1].mis);
}