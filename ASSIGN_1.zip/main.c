#include "tree.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
	bst t;
	initBST(&t);
	int choice;
	printf("CHOOSE : \n");
	do{
		printf("\n1. INSERT\n2. DELETE_NODE\n3. TRAVERSE [POSTORDER]\n4. DELETE_TREE\n5. SEARCH\n6. TRAVERSE [LEVEL]\n7. EXIT\n\n");
		scanf("%d", &choice);
		switch(choice) {
			case 1: {
				printf("ENTER MIS : \n");
				long long num;
				scanf("%lld", &num);
				printf("ENTER NAME : \n");
				char arr[100];
				int index;
				char c = getchar();
				while(1) {
					c = getchar();
					if(c == '\n')
						break;
					arr[index] = c;
					index += 1;
				}
				arr[index] = '\0';
				insertNode(&t, num, arr, t);
				break;
			}
			case 2: {
				long long key;
				printf("ENTER KEY TO DELETE : \n");
				scanf("%lld", &key);
				removeNode(&t, key);
				break;
			}
			case 3: {
				postorder(t);
				printf("\n");
				break;
			}
			case 4: {
				destroyTree(&t);
				break;
			}
			case 5: {
				long long key;
				printf("ENTER MIS TO SEARCH : \n");
				scanf("%lld", &key);
				if(search(t, key)) {
					printf("Element found\n\n");
				}
				else {
					printf("Element Not found\n\n"); 
				}
				break;
			}
			case 6: {
				printf("ENTER LEVEL TO TRAVERSE : \n");
				int level;
				scanf("%d", &level);
				Display_Level(t, level);
				printf("\n");
				break;
			}
			case 7: {
				break;
			}
		}
	}while(choice != 7);
	return 0;
}