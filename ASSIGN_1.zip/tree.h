#define boolean int


// FOR BST
typedef struct node {
	long long mis;
	char name[100];
	struct node *left, *right, *parent;
}node;

typedef node *bst;

void initBST(bst *t); // to initialize the tree.
void insertNode(bst *t, long long num, char *name, node *parent); // recursive function to add a new node to the tree.
void removeNode(bst *t, long long key); // to remove a node from a tree.
boolean search(bst t, long long key); // to recursive search for a node with the key and return a boolean value.
void postorder(bst t); // write a non-recursive function for post order traversal.
void Display_Level(bst t, int level); // to display all nodes of i th level.
void destroyTree(bst *t); // to delete all nodes of a tree



// FOR STACK

typedef struct stack {
	int top;
	int size;
	node *arr;
}stack;

void sinit(stack *s, int len);
void push(stack *s, node n);
node* pop(stack *s);
int isempty(stack s);
int isfull(stack s);
long long peek(stack s);